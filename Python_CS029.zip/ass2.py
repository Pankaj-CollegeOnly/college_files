#!/usr/bin/env python
# coding: utf-8

# In[2]:


# 1. Input: "welcome to the world of AI"
#    Output: "IA fo dlrow eht ot emoclew"
str = input('Enter the word your need to reverse')
print('Output :- '+str[::-1])


# In[3]:


# 2. Input : snack = "Chocolate cookie."
#     Output 1: cookie Output 2: Vanila

snack = input('Enter the Snack Name u want to replace')
a1 = snack.split()[1].strip(".") #the removal of Chocolate
a2 = "Valina"

print('Output :- '+a1+" "+a2)


# In[4]:


# Input: S1="welcome to the world of AI"
#        Output: wceohwloA

S1 = input('Enter the statement :- ')
S2 = S1[::3]
print(S2)


# In[10]:


# Q.4 Count and print the occurrence of word “AI” in following paragraph
#    "AI, or artificial intelligence, is revolutionizing various industries.
#    AI technologies are becoming increasingly important in today's world.
#    The future of AI looks promising."

Str1 = """AI, or artificial intelligence, is revolutionizing various industries.
AI technologies are becoming increasingly important in today's world.
The future of AI looks promising."""

Str2 = Str1.count('AI')
print('The total AI present in the statement is ',Str2)


# In[11]:


Str1 = """AI, or artificial intelligence, is revolutionizing various industries.
AI technologies are becoming increasingly important in today's world.
The future of AI looks promising."""

Str2 = Str1.replace('AI' , 'IOT')
print(Str2)


# In[20]:


# Q:6 Take string input as below and create a short form of list.
# Input : S1="welcome to the world of AI"
# Output : "WTTWOA"

input1 = input('Enter The statment :- ')
spliting = input1.split()
words= ""

for i in spliting :
     words += i[0:1].upper()

print(words)


# In[22]:


input2 = input('Enter The statment :- ')
spliting = input2.split()

print(spliting)


# In[23]:


# Q:8 Take string input as below and find the index value of a particular word "AI".
#     Input : S1="welcome to the world of AI"
#     Output: 24

input1 = input('Enter the Statement')
search = input1.index('AI')
print(search)


# In[24]:


# Q:9 Write a Python program to remove characters that have odd index values in a
#  given string.
#  Input: S1='welcome to the world of AI'
#  OUTPUT: wloet h ol fA

str1 = input('Enter the Statement :- ')
str2 = str1[::2]

print(str2)


# In[12]:


#Q:10 Write a Python program to count and display the vowels of a given String
#  S1="welcome to the world of AI"
#  Vowels Character : ['e', 'o', 'o', 'A', 'I']
#  Vowels Count : 5

str1 = input('Enter the statement :- ')
ct = str1.count('A')+str1.count('a')+str1.count('E')+str1.count('e')+str1.count('I')+str1.count('i')+str1.count('O')+ str1.count('o')+str1.count('U')+str1.count('u')
    
print(ct)

for i in str1:
    if i[0:]=='A' or i[0:]=='a' or i[0:]=='E' or i[0:]=='e' or i[0:]=='I' or i[0:]=='i' or i[0:]=='O' or i[0:]=='o' or i[0:]=='U' or i[0:]=='u':
        print(i)     
        
        


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




