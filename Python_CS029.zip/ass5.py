#!/usr/bin/env python
# coding: utf-8

# In[6]:


# 1. Write a function in python to read the content from a text file "poem.txt" line by line and display the
# same on screen.

def readLine() :
    myfile = open("poem.txt","r")
    data = myfile.readlines()

    for i in data :
        print(i)
    myfile.close()
    
readLine()


# In[10]:


def secondtry() :
    myfile = open("newFile.txt","r")
    data = myfile.readlines()
    
    for i in data :
        print(i)
    
    myfile.close()
secondtry()


# In[34]:


# 2. Write a function in python to count the number of lines from a text file "story.txt" which is not starting
# with an alphabet "T".

def findingT() :
    myfile = open("newFile.txt","r")
    data = myfile.readlines()
    cnt = 0
    
    for i in data :
        if(i[0] == "T") :
            cnt = cnt + 1
          
    print(cnt)
       
    myfile.close()
    
findingT()


# In[53]:


# 3. Write a function in Python to count and display the total number of words in a text file.

def words() :
    myfile = open("newFile.txt", "r")
    data = myfile.read()
    splits = data.split()
  
    cnt = 0
    for i in splits : 
        cnt = cnt+1
        
        
    print(cnt)
    myfile.close()
    
words()


# In[57]:


# Write a function in Python to read lines from a text file "notes.txt". Your function should find and display
# the occurrence of the word "the".

def file() :
    file = open("newFile.txt","r")
    data = file.read()
    splits = data.split()
    cnt =0
    
    for i in splits :
        if(i == "this") :
            cnt = cnt+1
    print(cnt)
    
file()


# In[60]:


# 5. Write a function display_words() in python to read lines from a text file "story.txt", and display those
# words, which are less than 4 characters.

def dsiplay_words() :
    file = open("newFile.txt", "r")
    data = file.read()
    splits = data.split()
    cnt =0 
    for i in splits :
        if( len(i)< 4 ) :
            cnt = cnt +1
    print(cnt)
    
dsiplay_words()


# In[3]:


# 6. Write a function in Python to count the words "this" and "these" present in a text file "article.txt". [Note
# that the words "this" and "these" are complete words]
def THISandThese() :
    file = open("article.txt","r")
    data = file.read()
    splits = data.lower().split()
    cnt = 0
    for i in splits :
        if ( i == "this" or i == "these") :
            cnt = cnt +1
    print(cnt)


    file.close()

THISandThese()


# In[6]:


# 7. Write a function in Python to count words in a text file those are ending with alphabet "e".

def FindingE() :
    file = open("article.txt","r")
    data = file.read()
    splits = data.split()
    cnt = 0
    
    for i in splits :
        if(i[-1] == "e") :
            cnt = cnt +1
            print(cnt,i)
            
    print(cnt)
    file.close()
FindingE()


# In[ ]:


# 8. Write a function in Python to count uppercase character in a text file.

def hash_display():
    f1 = open("article.txt","r")
    data = f1.read()
    for i in data:
        print(i,end="")
        print("#",end="")
    f1.close()
hash_display()



# In[ ]:


def JTOI():
    f1 = open("article.txt","r")
    data = f1.read()
    for i in data:
        if(i == "J"):
            print("I",end="")
        else:
            print(i,end="")
    f1.close()
JTOI()

