#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("Hello World")


# In[2]:


# Display personal information
name = "Pankaj"
lname = "Tomar"
enrollment = "SR23BSCS029"
Subject = "python"

print ('Hello '+ name+' '+lname+' '+'Your enrollment is '+enrollment+' '+'& subject is '+Subject)
    


# In[9]:


# Calculate Simple Interest
p = 30000
r = 3.5
t = 24
interest = p*r*t/100
print('Simple interest of the given values is', interest)


# In[14]:


# Define at least two people :age and name . Find the person is an adult people based
#on age. Display proper message.

name = input("Enter your name")
age = int(input('enter your age'))

if age >=19 :
    print('Your are an Adult')
else :
     print('Sorry, little kid you are Minor',name,' because your age is ',age,' But, age is just a number')


# In[18]:


# Input person name and city of a person. Display whether a person belongs to 'City' or
# 'Village'.

name = input("Enter your name :- ")
city = input('Enter city name')
village = input('Enter village name')

if city =='' :
    print('your are living in village')
elif village == '' :
    print('Your are living in city')
else :
    print('you can not live 2 both place or not allowed to blank the input')


# In[38]:


# Write a Python code which display multiplication table of 4.

tables = int(input())
i = 1
while i<=10 :
     print(tables,'x',i,'=',tables*i)
     i += 1


# In[39]:


# ODD or EVEN

number = int(input('Enter the number to '))

if number%2==0 :
    print('This is an even Number')
elif number%2!=0 :
    print('This is an oDD number ')
else :
    prit('Enter the number first')


# In[41]:


# Write a python code which take any three number and check the smallest number

num1 = int(input('Enter the First number '))
num2 = int(input('Enter the second number '))
num3 = int(input('Enter the third number '))
 
if num1<num2 and num1<num3 :
    print('Smallest number :- ', num1)
elif num2<num1 and num2<num3 :
    print('Smallest number :- ', num2)
elif num3<num1 and num3<num2 :
    print('Smallest number :- ', num3)


# In[5]:


# Write a python code which take three numbers and find the middle number from them..

num1 = int(input('Enter the 1 number '))
num2 = int(input('Enter The 2nd number '))
num3 = int(input('Enter The 3rd Number'))
maxium = max(num1,num2,num3)
minium = min(num1,num2,num3)

if num1 != maxium and num1 != minium :
    print('Middile number is ', num1)

elif num2 != maxium and num2 != minium :
    print('Middile number is ', num2)

elif num3 != maxium and num3 != minium :
    print('Middile number is ', num3)
else :
    print('All number are Same/ Invaild input')


# In[8]:


# Write a python code which take any 3 subject marks and calculate the total, percentage and
#grade

subject1 = int(input("Enter the marks of 1st subject"))
subject2 = int(input("Enter the marks of 2nd subject"))
subject3 = int(input("Enter the marks of 3rd subject"))
total = (subject1+subject2+subject3)
perct = (total/300) *100

if perct>=90 and perct<=100 :
    print('The total Marks is ',total,' and the percentage is ',perct,' the grade is A')
    
elif perct>=70 and perct<90 :
    print('The total Marks is ',total,' and the percentage is ',perct,' the grade is B')
elif perct>=50 and perct<70 :
    print('The total Marks is ',total,' and the percentage is ',perct,' the grade is C')
elif perct>=35 and perct<50 :
    print('The total Marks is ',total,' and the percentage is ',perct,' the grade is D')
else :
    print('The total Marks is ',total,' and the percentage is ',perct,' the grade is F')


# In[ ]:




