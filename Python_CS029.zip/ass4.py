#!/usr/bin/env python
# coding: utf-8

# In[2]:


def reversestr(str1):
    strrev = str1[::-1]
    return strrev

str1= input("Enter any string")
print("given str is reverse order : ")
print(reversestr(str1))


# In[5]:


def factorial(x):
    fact=1
    if x>0:
        for i in range(1,x+1):
            fact = fact*i
    else :
        print("Enter valid number")
    return fact 
num1 = int(input("Enter number"))
print("Factorial of given number : ")
print(factorial(num1))


# In[7]:


def RangeCheck(start,end,x):
    if start<=x<= end :
        print("given number in range")
    else :
        print("Not in range")
    
RangeCheck(1,10,14)


# In[9]:


def UpperLower(str1) :
    upper = 0
    lower = 0
    for char in str1 :
        if char.isupper():
            upper = upper+1
        elif char.islower():
            lower = lower+1
    print("Uppercase count : ",upper)
    print("lowercase count : ",lower)
str1 = input("Enter string : ")
UpperLower(str1)


# In[11]:


def DistinctElements(list1):
    list2 = set(list1)
    return list(list2)
list1 = [1,2,3,4,5,6,7,8,1,5,2,4,1,52,1]
print("Original list : ",list1)
print("Unique List elements : ",DistinctElements(list1))


# In[18]:


def prime(x):
    if x<=1:
        print("Not a Prime Number ")
        return
        
    count =0
    for i in range(1,x+1):
        if x%i ==0:
            count = count+1
    if count==2 :
        print("a Prime Number")
    else :
        print("Not a Prime Number")
            
print("Check given number is ")
num1 = int(input("Enter a Number : "))
prime(num1)


# In[1]:


def Palindrome(value):
    str1 = str(value)
    str2 = str1[::-1]
    if str1 == str2 :
        print("Palindrome")
    else :
        print("Not a Palindrome")
        
print("Check Given Value is Palindrome Or Not : ")
str1 = input("Enter Value : ")
Palindrome(str1)


# In[4]:


def listmultiply(list1):
    res=1
    for i in list1:
        res = res*i
    print("Multiply of Given list : ",res)
list1 = [1,2,3,4,5]
print("list : ",list1)
listmultiply(list1)


# In[5]:


def listsum(list1) :
    res=0
    for i in list1 :
        res = res+i
    print("Sum of given number", res)
list1 = [1,2,3,4,5,6]
print('list : ',list1)
listsum(list1)


# In[6]:


def Palindrome(value):
    str1 = str(value)
    str2 = str1[::-1]
    if str1 == str2 :
        print("Palindrome")
    else :
        print("Not a Palindrome")
        
print("Check Given Value is Palindrome Or Not : ")
str1 = input("Enter Value : ")
Palindrome(str1)


# In[10]:


def SwapNum(x,y):
    z=x
    x=y
    y=z
    
    print("num1 is : ",x)
    print("num2 is : ",y)
#     print("Z is : ",z)
    
num1 = int(input("Enter num1 "))
num2 = int(input("Enter num2 "))
print("Swapping of given number :")
SwapNum(num1,num2)


# In[11]:


def Year(year):
    if year%4==0 :
        print(year," Is a Leap Year")
    else :
        print(year," Is not a leap year")
year = int(input("Enter Year number 4digits"))
Year(year)


# In[16]:


# 14. Write a python to find sum of digits of inputted numbers.

def slipt(num):
    res =0
    for i in str(num):
        res = res+int(i)
        
    return res

num = int(input("Enter numer : "))
print("Sum of the number ")
slipt(num)


# In[13]:


def Multiplynum(num1):
    for i in range(1,11):
        print(num1 ," * ", i ," = ",num1*i)

num1 = int(input("Enter the number for table : "))
Multiplynum(num1)


# In[ ]:




