#!/usr/bin/env python
# coding: utf-8

# In[2]:


list1 = ['Physics','Chemistry',1997,2000]
list2 = [1, 2, 3, 4, 5, 6, 7 ]

print("List[0] : ",list1[0])
print("List[1:5] : ",list2[1:5])


# In[8]:


list1 = ['Physics','Chemistry',1997,2000]
list2 = [1, 2, 3, 4, 5, 6, 7 ]

print ("Value available at index 2 :",list[2])
list1[2] = 2001;
print ("New value available at index 2 : ",list[2])


# In[9]:


list1,list2 = [123, 'xyz','zara'], [456,'abc']

print("First list lenght : ", len(list1))
print("First list lenght : ", len(list2))


# In[11]:


list1 = ["a", "b", "c", "d"]
list2 = [25.50, True, -55, 1+2j]

print ("Item at 0th index in list1: ", list1[0])
print ("Item at index 2 in list2: ", list2[-3])
print ("Items from index 1 to 2 in list1: ", list1[1:3])
print ("Items from index 0 to 1 in list2: ", list2[0:2])


# 

# In[12]:


list3 = [1,2,3,4,5]
print("Original list", list3)
list3[2] = 10
print("List after changing value at index 2 :", list3)


# In[14]:


list1 = ["a", "b", "c", "d"]
print("Original list : ", list1)
list2 = ['X','Y','Z']
list1[1:3] = list2
print("Listen after chnaging with sublist : ",list1)


# In[15]:


list1 = ["Rohan","Physics",21,69.75]
print("Original lsit",list1)
list1.insert(2,'Chemistry')
print("list after Appending :- ",list1)
list1.insert(-1,'PASS')
print("List after Appending :- ", list1)


# In[16]:


list1 = ["a", "b", "c", "d"]
print("Original lsit :- ", list1)
list1.append('e')
print("list After appending :- ",list1)


# In[18]:


list1 = ["Rohan","Physics",21,69.75]
print("Original list :- ",list1)
list1.remove("Physics")
print("Original after removing :- ",list1)


# In[20]:


tup1 = ('physics', 'Chemistry',1997,2000)
tup2 = (1,2,3,4,5,6,7)
print("tup1[0]",tup1[0])
print("tup2[1:5]",tup2[1:5])


# In[23]:


tup1 =(12,34.56)
tup2 = ('abc','xyz')
# Following action is not valid for tuples
# tup1[0] = 100;
# print(tup1)

tup3 = tup1+tup2
print(tup3)


# In[24]:


tup = ('physics','chemistry',1997,2000)
print(tup)
del(tup)
print("After deleting  tup :-")
print(tup)


# In[25]:


# Q:1 Write a Python program to sum all the items in a list.
list1 = [1,2,3,4,5]
print(sum(list1))


# In[29]:


# Q:2 Write a Python program to remove duplicates from a list

list1 = [11,11,22,22,11,33,44,66,11,44,22,99,11,13,15,43]

print(set(list1))
list2 = []
for i in list1 :
    if i not in list2 :
        list2.append(i)
    
print(list2)


# In[30]:


# Q:3Write a Python program to print the numbers of a specified list after removing even numbers from it.
list1 = [1,2,3,4,56,64,8,4584,65]
list2 =[]

for i in list1 :
    if i%2!=0 :
        list2.append(i)
        
print(list2)


# In[41]:


# Q:4 Create an empty list in python and append English dictionary words to the list. Arrange list
# items In alphabetical order and find the position of specific words in the list.

list1 = []
list1.append("Roman")
list1.append("Search")
list1.append("jksbv")
list1.append("asdvf")
list1.append("jwefksaswfbv")
list1.append("jakaswdvfsbv")
list1.append("jzwefksbv")
print(list1)

# print('After sorting in list1 ',sorted(list1))
var = input("Enter the word :- ")
for i in range(len(list1)):
        if var == list1[i] :
            print(var," on position ",i)


# In[42]:


# Q:5 Convert two lists into a dictionary

list1 = [1,2,3,4,5]
list2 = [6,7,8,9,10]
print("list before zipping ",list1)
print("list before zipping ",list2)
list3 = dict(zip(list1,list2))
print("After make it in dictionary format :- ",list3)


# In[45]:


# Q:6 Write a python program to access only key of the dictionary

dict1 = {"name": "tonny","Age":28,"country": "America"}

print("Original Dictionary :- ",dict1)
print("only keys :- ",dict.keys(dict1))


# In[46]:


# Q:7 Write a python program to access only the value of the dictionary.
dict1 = {"name": "tonny","Age":28,"country": "America"}

print("Original Dictionary :- ",dict1)
print("only values :- ",dict.values(dict1))


# In[47]:


# Q:8 Merge two Python dictionaries into one
dict1 = {"name": "tonny","Age":28,"country": "America"}
dict2 = {"Sport": "Football","Postion": "Keeper"}
dict1.update(dict2)
print(dict1)


# In[49]:


# Q:9 Get the key of a minimum value from the following dictionary

dict1= {1:5,2:5,6:5,1:1}
list1 = list(dict1.keys())
print(min(list1))


# In[53]:


# Q:10 Write a Python program to find repeated items in a tuple
tuples1 = [11,22,3,11,22,22,5,5]
var2 = []
  


# In[ ]:





# In[ ]:




